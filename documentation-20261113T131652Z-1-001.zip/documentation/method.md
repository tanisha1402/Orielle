# Method: TERRALENS Mission 01, Jamuna River flood

**Confidence status: EXPERIMENTAL.** Experimental: the method runs and the output looks reasonable, but its accuracy has not been confirmed against independent imagery.

## 1. What this analysis answers
Where did new water appear between 2020-07-13 and 2020-07-25, and roughly how large is that area?
It estimates *new surface water*. It does not measure damage to buildings, roads or crops.

## 2. Data
| Item | Value |
|---|---|
| Sensor | Sentinel-1 (C-band SAR). This is not NISAR and the threshold must not be reused for NISAR. |
| Polarization | VV |
| Before / after dates | 2020-07-13 / 2020-07-25 |
| Scene IDs | S1A_IW_GRDH_1SDV_20200713T120451_20200713T120516_033436_03DFD8_67E8, S1A_IW_GRDH_1SDV_20200725T120452_20200725T120517_033611_03E538_4162 |
| Product and preprocessing | Sentinel-1A GRD High Resolution, IW mode, ascending, relative orbit 114, VV used (VV and VH acquired), processed with ASF HyP3, aligned to a common 10 m grid (EPSG:32646) in QGIS and converted to Cloud Optimized GeoTIFF. Calibration, speckle filter and terrain-correction settings are not recorded in the data-prep summary (to confirm with Shosi). |
| Grid | EPSG:32646, pixel size 10 m, 2051 x 2041 pixels |
| Area analysed | 398 km2 of valid pixels |
| Attribution | Contains modified Copernicus Sentinel data |

## 3. Method
1. Both images are in dB on the same grid. NoData and the common-validity mask are excluded, so they are never counted as land or water.
2. A pixel is **water** if its backscatter is below the threshold of **-16 dB** (water is smooth and reflects radar away, so it looks dark).
3. Water patches smaller than 50 pixels (0.005 km2) are removed to reduce speckle noise.
4. Classes: 0 land, 1 permanent water (dark before and after), 2 new water (dark after only), 255 NoData.
5. Area = number of class-2 pixels x pixel area from the raster transform / 1,000,000 (km2).

## 4. Threshold and why
Chosen threshold: **-16 dB.**

Otsu's automatic threshold on the valid after-date pixels was -16.03 dB; the smoothed histogram's valley between the water and land peaks was at about -14.0 dB; across candidate thresholds -18 to -14 dB the new-water estimate ranges from 25.2 to 42.9 km2; the visual comparison of candidates in QGIS is still pending.

Sensitivity of the result to the threshold:

| Threshold (dB) | Permanent water (km2) | New water (km2) |
|---|---|---|
| -18 | 189.7 | 42.9 |
| -16 | 230.6 | 29.0 |
| -14 | 251.4 | 25.2 |

## 5. Result
- Estimated new water: **29.0 km2** (7.3% of the analysed area)
- Permanent water: 230.6 km2 (57.9%)
- Because of threshold sensitivity, quote this as an estimate with a range, not a single exact value.

## 6. Validation
114 random points were labelled as water / not water on the after date (4 sample points fell on NoData and were skipped).

- Accuracy: **100%** (95% confidence interval 97% to 100%)
- Precision (flagged water that was water): 100%
- Recall (real water that was found): 100%
- Independent reference imagery used: no (labels partly or fully judged on the SAR image itself)
- Provisional SAR-only labels still included: 0

## 7. Known limits
| Limit | Effect |
|---|---|
| Wet soil | Looks dark like water, so it can be counted as water |
| Radar shadow | Land behind hills or tall objects looks dark. No DEM-based shadow mask is applied yet |
| Water under trees | Hidden by leaves, so real flooding can be missed |
| Windy water | Rough water looks bright and can be missed |
| One date pair | Only two observations; this cannot show how the flood evolved over time |
| Threshold choice | One fixed threshold for the whole scene; a different value changes the area noticeably |
| Radar is not damage proof | A flooded pixel is potential exposure, not confirmed damage to a road or building |

## 8. In-game explanation text
**How did we find the flood?**
Mission Control compared two radar images of the Jamuna River, taken on 2020-07-13 and 2020-07-25. Water is smooth, so it bounces the radar signal away and looks dark. Pixels that were dark in the second image but not in the first are marked as new water.

**How sure are we?**
This map is experimental. The method works, but we have not yet proven how accurate it is, so treat the area as an estimate.

**What can radar not tell you?**
Radar can confuse wet soil and radar shadows with water, and it can miss water hidden under trees. A flood map shows where water probably is. It does not show which buildings or roads are damaged.

## 9. Reproducibility
Code: `research/detection/detect.py`. Parameters: threshold -16 dB, minimum patch 50 pixels. Outputs: `data/cog/change.tif`, `data/results/result.json`. Validation: `research/validation_labels.csv`, `research/validation_metrics.json`. Decision record: `documentation/threshold_decision.json`.

## Note on validation
The 114 reference labels were derived from the after-date SAR image itself, so they agree with the model by construction. The 100% accuracy figure is a consistency check, not independent validation. Independent validation against georeferenced optical imagery (for example NASA Worldview, 26 July 2020) is pending.
