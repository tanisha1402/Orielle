# Sentinel-1 SAR Scene Metadata

## Study Area
Jamuna River, Bangladesh

## Before-Flood Scene
- **Scene ID:** `S1A_IW_GRDH_1SDV_20200713T120451_20200713T120516_033436_03DFD8_67E8`
- **Acquisition date:** 13 July 2020
- **Acquisition time:** 12:04:51 UTC
- **Satellite:** Sentinel-1A
- **Mode:** Interferometric Wide (IW)
- **Product:** GRD High Resolution (GRD_HD)
- **Orbit direction:** Ascending
- **Relative orbit:** 114
- **Polarization:** VV+VH

## After-Flood Scene
- **Scene ID:** `S1A_IW_GRDH_1SDV_20200725T120452_20200725T120517_033611_03E538_4162`
- **Acquisition date:** 25 July 2020
- **Acquisition time:** 12:04:52 UTC
- **Satellite:** Sentinel-1A
- **Mode:** Interferometric Wide (IW)
- **Product:** GRD High Resolution (GRD_HD)
- **Orbit direction:** Ascending
- **Relative orbit:** 114
- **Polarization:** VV+VH

## Scene Selection and Consistency
Both scenes intersect the study-area AOI and were selected from the ASF DAAC catalog.

They share the same satellite, acquisition mode, orbit direction, relative orbit and polarization. Their matching acquisition geometry makes them suitable for before-and-after SAR backscatter comparison.

**Acquisition interval:** 12 days.
