# River Gauge Validation – Jamuna Flood, July 2020

## Gauge Station
- **Station:** Bahadurabad
- **River:** Jamuna
- **Data source:** Bangladesh Water Development Board (BWDB), Flood Forecasting and Warning Centre (FFWC)

## Historical Water-Level Evidence
According to the FFWC Annual Flood Report 2020:

- **Danger level:** 19.50 m PWD
- **Peak water level in 2020:** 20.79 m PWD
- **Date of annual peak:** 16 July 2020
- **Duration above danger level:** 40 days during the 2020 monsoon

The recorded peak was 1.29 m above the danger level.

## Relation to SAR Acquisitions
- Before-flood SAR acquisition: 13 July 2020
- After-flood SAR acquisition: 25 July 2020

The documented July 2020 high-water event provides independent hydrological context for the SAR investigation.

Exact daily gauge readings for 13 July and 25 July have not yet been independently verified and are therefore not reported here.

## Source
Bangladesh Water Development Board, Flood Forecasting and Warning Centre. *Annual Flood Report 2020*, Chapter 3, section on the Jamuna at Bahadurabad.

Official report: https://api.ffwc.gov.bd/assets/annual-reports/annual20.pdf
