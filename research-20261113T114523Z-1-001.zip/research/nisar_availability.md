# NISAR Data Availability

## Study Event
- **Location:** Jamuna River, Bangladesh
- **Flood study period:** July 2020

## NISAR Data Availability
The July 2020 flood event predates the availability of public NISAR science data.

NISAR science data became publicly available in July 2026, covering acquisitions from 17 June 2026 onward. Therefore, no contemporaneous NISAR observation is available for this 2020 flood event.

## Data Used Instead
Sentinel-1A SAR imagery was used for the flood investigation:

- Before-flood acquisition: 13 July 2020
- After-flood acquisition: 25 July 2020
- Polarization: VV+VH
- Relative orbit: 114
- Orbit direction: Ascending

## Conclusion
Sentinel-1A was selected as the available historical SAR data source. NISAR is identified as the future mission context for TERRALENS, but its data was not used to analyze the July 2020 event.
