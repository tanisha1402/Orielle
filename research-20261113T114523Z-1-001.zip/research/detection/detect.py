
import numpy as np
from scipy import ndimage


def water_mask(db, threshold=-16.0, min_pixels=50, valid_mask=None, nodata=None):
    """
    Identify water pixels from SAR backscatter in dB.

    Parameters:
        db: 2D SAR backscatter array.
        threshold: pixels darker (lower) than this are considered water.
        min_pixels: minimum connected-component size to retain (removes speckle noise).
        valid_mask: optional boolean array; False pixels are excluded.
        nodata: optional sentinel value (e.g. -9999) to treat as missing.

    Returns:
        Boolean array: True where water.
    """
    valid = np.isfinite(db)

    if nodata is not None:
        valid &= (db != nodata)

    if valid_mask is not None:
        if valid_mask.shape != db.shape:
            raise ValueError("Validity mask shape must match image.")
        valid &= valid_mask.astype(bool)

    mask = valid & (db < threshold)

    labels, n = ndimage.label(mask)
    if n == 0:
        return np.zeros(mask.shape, dtype=bool)

    sizes = ndimage.sum(mask, labels, range(1, n + 1))
    retained_labels = np.flatnonzero(sizes >= min_pixels) + 1

    return np.isin(labels, retained_labels)


def classify(before_db, after_db, threshold=-16.0, valid_mask=None,
             before_nodata=None, after_nodata=None, min_pixels=50):
    """
    Classify pixels into:
        0   = Land
        1   = Permanent water (dark before AND after)
        2   = New floodwater (dark after only)
        255 = NoData

    Only pixels valid in both images (and in valid_mask, if given) are classified;
    everything else is marked 255 so it is never silently counted as land or water.
    """
    if before_db.shape != after_db.shape:
        raise ValueError("Before and after images must have identical shapes.")

    valid = np.isfinite(before_db) & np.isfinite(after_db)

    if before_nodata is not None:
        valid &= (before_db != before_nodata)
    if after_nodata is not None:
        valid &= (after_db != after_nodata)

    if valid_mask is not None:
        if valid_mask.shape != before_db.shape:
            raise ValueError("Validity mask shape must match image.")
        valid &= valid_mask.astype(bool)

    before_water = water_mask(before_db, threshold=threshold, min_pixels=min_pixels,
                               valid_mask=valid, nodata=before_nodata)
    after_water = water_mask(after_db, threshold=threshold, min_pixels=min_pixels,
                              valid_mask=valid, nodata=after_nodata)

    out = np.full(before_db.shape, 255, dtype=np.uint8)
    out[valid] = 0
    out[valid & before_water & after_water] = 1
    out[valid & after_water & ~before_water] = 2

    return out


def new_water_km2(change, transform):
    """Area of class-2 (new floodwater) pixels, in km^2, using the raster's own pixel size."""
    pixel_m2 = abs(transform.a * transform.e)
    return float((change == 2).sum() * pixel_m2 / 1_000_000)
