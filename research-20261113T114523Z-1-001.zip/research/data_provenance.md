# **`SAR Data Provenance and Processing`**

## **`1. Data Source`**

* **`Satellite:`** `Sentinel-1A`  
* **`Data provider:`** `Alaska Satellite Facility (ASF) DAAC`  
* **`Processing service:`** `ASF HyP3`  
* **`Product type:`** `Ground Range Detected (GRD), High Resolution`  
* **`Study area:`** `Jamuna River, Bangladesh`

## **`2. Input SAR Scenes`**

### **`Before-Flood Image`**

* **`Acquisition date:`** `13 July 2020`  
* **`Scene ID:`** `S1A_IW_GRDH_1SDV_20200713T120451_20200713T120516_033436_03DFD8_67E8`

### **`After-Flood Image`**

* **`Acquisition date:`** `25 July 2020`  
* **`Scene ID:`** `S1A_IW_GRDH_1SDV_20200725T120452_20200725T120517_033611_03E538_4162`

`Both scenes were acquired by Sentinel-1A using the Interferometric Wide (IW) mode, ascending orbit, relative orbit 114, with VV and VH polarizations. The selected VV-polarization products were used for comparison.`

## **`3. Processing`**

`The Sentinel-1 GRD scenes were processed using ASF HyP3.`

`The selected VV-polarization backscatter products were prepared for before-and-after comparison. Both images were aligned to a common spatial grid to ensure consistent geographic positioning.`

`The two images have matching:`

* `Coordinate Reference System`  
* `Spatial extent`  
* `Raster dimensions`  
* `Pixel size`  
* `Grid origin`

## **`4. Final Output Image Information`**

`The final prepared images are:`

| `Property` | `Before image` | `After image` |
| :---- | :---- | :---- |
| `Filename` | `before.tif` | `after.tif` |
| `Acquisition date` | `13 July 2020` | `25 July 2020` |
| `Polarization` | `VV` | `VV` |
| `CRS` | `EPSG:32646` | `EPSG:32646` |
| `Pixel size` | `10 m` | `10 m` |
| `Dimensions` | `2051 × 2041` | `2051 × 2041` |
| `Data type` | `Float32` | `Float32` |
| `NoData value` | `-9999` | `-9999` |
| `Format` | `Cloud Optimized GeoTIFF` | `Cloud Optimized GeoTIFF` |

**`Spatial extent:`**

* `Minimum X: 157160 m`  
* `Minimum Y: 2780970 m`  
* `Maximum X: 177670 m`  
* `Maximum Y: 2801380 m`

## **`5. Final COG Conversion and Verification`**

`The final Sentinel-1 VV images were converted to Cloud Optimized GeoTIFF (COG) format using GDAL 3.13.3.`

* **`Before image:`** `before.tif`  
* **`After image:`** `after.tif`  
* **`Output format:`** `Cloud Optimized GeoTIFF (COG)`  
* **`Compression:`** `LZW`  
* **`Raster dimensions:`** `2051 × 2041 pixels`  
* **`CRS:`** `EPSG:32646`  
* **`Pixel size:`** `10 m`

`COG compliance was verified for both output files using GDAL image structure metadata. Both files returned LAYOUT=COG.`

`The original GeoTIFF files were retained separately. The verified COG versions were uploaded to the project's data/cog/ directory.`

## **`6. Data Organization`**

`The project data is organized as follows:`

* `data/raw/ — Original downloaded SAR data`  
* `data/cog/ — Prepared and verified COG before-and-after images`  
* `data/aoi.geojson — Study area boundary`  
* `research/ — Scene metadata, data provenance, NISAR availability, gauge information and supporting imagery`

## **`7. NASA Worldview Optical Reference`**

`The file Jamuna_Worldview_20200726.png provides supplementary optical visual context for the Jamuna River study area.`

* **`Source:`** `NASA Worldview`  
* **`Image date:`** `26 July 2020`  
* **`Image type:`** `True-colour optical imagery`  
* **`Purpose:`** `Supplementary visual reference for the flood investigation`

`This image was selected because clearer optical imagery was available on 26 July, while nearby dates had cloud interference. It is one day after the 25 July Sentinel-1 acquisition and is not an exact date-matched comparison.`

`Optical imagery is used only as supporting visual context and does not replace the SAR observations.`

## **`8. Data Acknowledgement`**

`Contains modified Copernicus Sentinel data, processed by ESA and retrieved through ASF DAAC.`

## **`9. Notes and Limitations`**

`Both Sentinel-1 images use matching acquisition geometry and spatial alignment, supporting comparative SAR backscatter analysis.`

`The 13 July image represents the pre-event reference, while the 25 July image represents the later observation following the documented mid-July river-level peak.`

`The NASA Worldview image is supplementary optical context from 26 July 2020.`

`No contemporaneous NISAR observation is available for this July 2020 event. Sentinel-1 data was therefore used for the SAR investigation.`

&nbsp;

&nbsp;