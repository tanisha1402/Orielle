# How water looks in radar

*TERRALENS · ML research notes · `research/notes.md`*

## The basic idea

Radar satellites send a signal down and measure how much comes back. This returned signal is called **backscatter**.

- **Water is smooth.** It bounces the signal away from the satellite, so very little comes back. Water looks **dark**.
- **Land is rougher.** It sends more signal back, so it looks **brighter**.

A flood shows up as an area that was land in the "before" picture and is dark in the "after" picture.

## The dB scale

Radar pictures are shown in **dB** (decibels). This scale makes dark water and bright land easy to compare.

- Very low numbers (very negative, such as **−20 dB**) usually mean water.
- Higher numbers (closer to 0, or above) usually mean land.

## The first-guess threshold

A **threshold** is the cut-off number. A pixel darker than the threshold is marked as water.

- Starting guess: **−16 dB**.
- **This is a first guess, not a rule.**

Choose the final value by looking at the histogram, not by trusting −16 dB everywhere.

> **My chosen threshold:** -16 dB
> **Why I chose it:** Otsu's automatic threshold on the valid after-date pixels was -16.03 dB; the smoothed histogram's valley between the water and land peaks was at about -14.0 dB; across candidate thresholds -18 to -14 dB the new-water estimate ranges from 25.2 to 42.9 km2; the visual comparison of candidates in QGIS is still pending.

## Things that can fool the method

| Problem | What happens |
| --- | --- |
| **Wet soil** | Looks dark like water, but it is land |
| **Radar shadow** | Land behind tall hills or buildings gets no signal, so it looks dark |
| **Water under trees** | Leaves hide the water, so a real flood is missed |
| **Windy water** | Wind makes the surface rough, so water looks bright like land |

## New water vs. permanent water

A river that was already there before the flood is **not** a flood. Only water that is **new** counts.

In `change.tif`:

| Value | Meaning |
| --- | --- |
| 0 | Land |
| 1 | Permanent water (dark before **and** after) |
| 2 | New water (dark after only) |

## Keep in mind

- Empty pixels (no data) are ignored, not counted as water.
- Sentinel-1 and NISAR use different wavelengths. Never reuse a threshold from one on the other.
- Be honest about accuracy.
